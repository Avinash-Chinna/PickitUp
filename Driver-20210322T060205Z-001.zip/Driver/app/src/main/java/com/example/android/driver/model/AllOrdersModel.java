package com.example.android.driver.model;

public class AllOrdersModel {
    String orderID;
    String vehicleType;
    String pickupLocation;
    String dropLocation;
    String date;

    public AllOrdersModel(String orderID, String vehicleType, String pickupLocation, String dropLocation, String date) {
        this.orderID = orderID;
        this.vehicleType = vehicleType;
        this.pickupLocation = pickupLocation;
        this.dropLocation = dropLocation;
        this.date = date;
    }

    public String getOrderID() {
        return orderID;
    }

    public void setOrderID(String orderID) {
        this.orderID = orderID;
    }

    public String getVehicleType() {
        return vehicleType;
    }

    public void setVehicleType(String vehicleType) {
        this.vehicleType = vehicleType;
    }

    public String getPickupLocation() {
        return pickupLocation;
    }

    public void setPickupLocation(String pickupLocation) {
        this.pickupLocation = pickupLocation;
    }

    public String getDropLocation() {
        return dropLocation;
    }

    public void setDropLocation(String dropLocation) {
        this.dropLocation = dropLocation;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }


}


